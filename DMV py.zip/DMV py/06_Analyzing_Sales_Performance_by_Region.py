import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

DATA_PATH = "./datasets/customer_shopping_data.csv"

try:
    df = pd.read_csv(DATA_PATH)
    print("Loaded original dataset:", DATA_PATH)

except FileNotFoundError:
    rng = np.random.default_rng(42)
    n = 1000

    malls = [
        "Cevahir AVM", "Emaar Square Mall", "Forum Istanbul",
        "Istinye Park", "Kanyon", "Mall of Istanbul",
        "Metrocity", "Metropol AVM", "Viaport Outlet",
        "Zorlu Center"
    ]

    categories = [
        "Books", "Clothing", "Cosmetics", "Food & Beverage",
        "Shoes", "Souvenir", "Technology", "Toys"
    ]

    price_ranges = {
        "Books": (5, 80),
        "Clothing": (20, 600),
        "Cosmetics": (10, 150),
        "Food & Beverage": (2, 30),
        "Shoes": (100, 900),
        "Souvenir": (3, 60),
        "Technology": (300, 5000),
        "Toys": (10, 250)
    }

    chosen_categories = rng.choice(categories, n)

    prices = [
        round(rng.uniform(*price_ranges[c]), 2)
        for c in chosen_categories
    ]

    quantities = rng.integers(1, 6, n)

    df = pd.DataFrame({
        "invoice_no": rng.integers(1000000, 1999999, n),
        "customer_id": [f"C{i:06d}" for i in range(n)],
        "gender": rng.choice(["Female", "Male"], n),
        "age": rng.integers(18, 75, n),
        "category": chosen_categories,
        "quantity": quantities,
        "price": prices,
        "payment_method": rng.choice(
            ["Credit Card", "Debit Card", "Cash"], n
        ),
        "invoice_date": pd.date_range(
            "2021-01-01", periods=n, freq="D"
        ).strftime("%d/%m/%Y"),
        "shopping_mall": rng.choice(malls, n)
    })

print("\nDataset Shape:", df.shape)

print("\nFirst Five Records:")
print(df.head().to_string(index=False))

print("\nLast Five Records:")
print(df.tail().to_string(index=False))

print("\nTransactions by Shopping Mall:")
print(
    df.groupby("shopping_mall")
    .size()
    .sort_values(ascending=False)
    .to_string()
)

print("\nTransactions by Product Category:")
print(
    df.groupby("category")
    .size()
    .sort_values(ascending=False)
    .to_string()
)

branch_sales = df.groupby("shopping_mall").agg(
    total_quantity=("quantity", "sum"),
    total_sales=("price", "sum"),
    transactions=("invoice_no", "count")
).sort_values("total_sales", ascending=False)

category_sales = df.groupby("category").agg(
    total_quantity=("quantity", "sum"),
    total_sales=("price", "sum"),
    transactions=("invoice_no", "count")
).sort_values("total_sales", ascending=False)

print("\nSales Summary by Shopping Mall:")
print(branch_sales.to_string())

print("\nSales Summary by Product Category:")
print(category_sales.to_string())

combined_branch_category_sales = df.groupby(
    ["shopping_mall", "category"]
)[["quantity", "price"]].sum()

print("\nCombined Shopping Mall and Category Sales:")
print(combined_branch_category_sales.head(10).to_string())

plt.figure(figsize=(8, 5))
plt.pie(
    branch_sales["total_sales"],
    labels=branch_sales.index,
    autopct="%1.1f%%",
    startangle=90
)
plt.title("Sales by Shopping Mall")
plt.tight_layout()
plt.show()

plt.figure(figsize=(8, 5))
plt.pie(
    category_sales["total_sales"],
    labels=category_sales.index,
    autopct="%1.1f%%",
    startangle=90
)
plt.title("Sales by Product Category")
plt.tight_layout()
plt.show()

combined_pivot = df.pivot_table(
    index="shopping_mall",
    columns="category",
    values="price",
    aggfunc="sum",
    fill_value=0
)

combined_pivot.plot(kind="bar", figsize=(12, 6))
plt.title("Sales by Product Category at Each Shopping Mall")
plt.xlabel("Shopping Mall")
plt.ylabel("Sales")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()
plt.show()

print("\nPractical 6 executed successfully.")