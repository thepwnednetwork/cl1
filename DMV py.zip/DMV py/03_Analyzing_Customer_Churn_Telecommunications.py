import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

rng = np.random.default_rng(7)
n = 500

data = pd.DataFrame({
    "customerID": [f"C{i:04d}" for i in range(n)],
    "gender": rng.choice(["Female", "Male"], n),
    "SeniorCitizen": rng.choice([0, 1], n, p=[0.84, 0.16]),
    "Partner": rng.choice(["Yes", "No"], n),
    "Dependents": rng.choice(["Yes", "No"], n),
    "tenure": rng.integers(0, 73, n),
    "PhoneService": rng.choice(["Yes", "No"], n),
    "InternetService": rng.choice(["DSL", "Fiber optic", "No"], n),
    "Contract": rng.choice(
        ["Month-to-month", "One year", "Two year"],
        n,
        p=[0.55, 0.25, 0.20]
    ),
    "PaymentMethod": rng.choice(
        ["Electronic check", "Mailed check", "Bank transfer", "Credit card"],
        n
    ),
    "MonthlyCharges": np.round(rng.uniform(18.25, 118.75, n), 2),
    "TotalCharges": np.round(rng.uniform(18, 8500, n), 2),
    "Churn": rng.choice(["Yes", "No"], n, p=[0.27, 0.73])
})

data.loc[[4, 21], "TotalCharges"] = np.nan
data = pd.concat([data, data.iloc[[0]]], ignore_index=True)

print("Shape:", data.shape)
print("\nFirst Five Records:")
print(data.head().to_string(index=False))

print("\nColumns:")
print(data.columns.tolist())

print("\nDataset Information:")
data.info()

print("\nMissing Values Before Cleaning:")
print(data.isnull().sum())

print("\nDuplicate Rows:", data.duplicated().sum())

data_cleaned = data.drop_duplicates().copy()

data_cleaned["TotalCharges"] = data_cleaned["TotalCharges"].fillna(
    data_cleaned["TotalCharges"].median()
)

print("\nShape After Cleaning:", data_cleaned.shape)

print("\nMissing Values After Cleaning:")
print(data_cleaned.isnull().sum())

print("\nStatistical Summary:")
print(data_cleaned.describe(include="all").T.to_string())

for column in ["tenure", "MonthlyCharges", "Churn", "Contract"]:
    print(f"\nFrequency Distribution: {column}")
    print(data_cleaned[column].value_counts().head(15).to_string())

fig, axes = plt.subplots(1, 2, figsize=(10, 4))

data_cleaned["Churn"].value_counts().plot(kind="bar", ax=axes[0])
axes[0].set_title("Customer Churn")
axes[0].set_xlabel("Churn")
axes[0].set_ylabel("Number of Customers")

contract_churn = pd.crosstab(
    data_cleaned["Contract"],
    data_cleaned["Churn"]
)

contract_churn.plot(kind="bar", ax=axes[1])
axes[1].set_title("Churn by Contract Type")
axes[1].set_xlabel("Contract Type")
axes[1].set_ylabel("Number of Customers")
axes[1].tick_params(axis="x", rotation=25)

plt.tight_layout()
plt.show()

colors = data_cleaned["Churn"].map({
    "Yes": "red",
    "No": "blue"
})

plt.figure(figsize=(6, 4))
plt.scatter(
    data_cleaned["tenure"],
    data_cleaned["MonthlyCharges"],
    c=colors,
    alpha=0.6
)
plt.title("Tenure vs Monthly Charges")
plt.xlabel("Tenure (months)")
plt.ylabel("Monthly Charges")
plt.tight_layout()
plt.show()

plt.figure(figsize=(6, 4))
plt.boxplot(data_cleaned["tenure"])
plt.title("Box Plot of Tenure")
plt.ylabel("Tenure (months)")
plt.tight_layout()
plt.show()

plt.figure(figsize=(6, 4))
plt.boxplot(data_cleaned["MonthlyCharges"])
plt.title("Box Plot of Monthly Charges")
plt.ylabel("Monthly Charges")
plt.tight_layout()
plt.show()

print("\nPractical 3 executed successfully.")