import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

USE_LIVE_API = False  # Change to True only when you have a valid API key.
API_KEY = os.getenv("OPENWEATHER_API_KEY", "")

weather_df = None
if USE_LIVE_API and API_KEY:
    try:
        import requests
        response = requests.get(
            "https://api.openweathermap.org/data/2.5/forecast",
            params={"lat": 18.5204, "lon": 73.8567, "appid": API_KEY, "units": "metric"},
            timeout=15
        )
        response.raise_for_status()
        payload = response.json()
        rows = []
        for item in payload.get("list", []):
            rows.append({
                "Timestamp": item.get("dt_txt"),
                "Temperature": item.get("main", {}).get("temp"),
                "Humidity": item.get("main", {}).get("humidity"),
                "Wind_Speed": item.get("wind", {}).get("speed"),
                "Weather_Description": (item.get("weather") or [{}])[0].get("description", "unknown")
            })
        if rows:
            weather_df = pd.DataFrame(rows)
    except Exception as exc:
        print("Live API request failed; using sample data instead.", exc)

if weather_df is None:
    dates = pd.date_range("2024-10-25", periods=48, freq="3h")
    rng = np.random.default_rng(42)
    weather_df = pd.DataFrame({
        "Timestamp": dates,
        "Temperature": np.round(25 + 3*np.sin(np.arange(48)/8) + rng.normal(0, 0.8, 48), 2),
        "Humidity": rng.integers(35, 75, 48),
        "Wind_Speed": np.round(rng.uniform(0.5, 5.5, 48), 2),
        "Weather_Description": rng.choice(["clear sky", "few clouds", "scattered clouds"], 48)
    })

weather_df["Timestamp"] = pd.to_datetime(weather_df["Timestamp"], errors="coerce")
weather_df = weather_df.dropna(subset=["Timestamp"]).sort_values("Timestamp").reset_index(drop=True)
weather_df.head()

print(weather_df.info())
print("\\nMissing values:\\n", weather_df.isnull().sum())
weather_df[["Temperature", "Humidity", "Wind_Speed"]] = weather_df[["Temperature", "Humidity", "Wind_Speed"]].apply(
    lambda col: col.fillna(col.mean())
)
weather_df.describe()

weather_df["Date"] = weather_df["Timestamp"].dt.date
daily_mean = weather_df.groupby("Date", as_index=False)[["Temperature", "Humidity", "Wind_Speed"]].mean()
display(daily_mean.head())

plt.figure(figsize=(9, 4))
plt.plot(daily_mean["Date"].astype(str), daily_mean["Temperature"], marker="o")
plt.title("Mean Daily Temperature")
plt.xlabel("Date")
plt.ylabel("Temperature (°C)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

plt.figure(figsize=(9, 4))
plt.bar(daily_mean["Date"].astype(str), daily_mean["Humidity"])
plt.title("Mean Daily Humidity")
plt.xlabel("Date")
plt.ylabel("Humidity (%)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

plt.figure(figsize=(6, 4))
plt.scatter(weather_df["Temperature"], weather_df["Wind_Speed"], alpha=0.7)
plt.title("Temperature vs. Wind Speed")
plt.xlabel("Temperature (°C)")
plt.ylabel("Wind Speed (m/s)")
plt.grid(True)
plt.tight_layout()
plt.show()

plt.figure(figsize=(7, 4))
sns.heatmap(weather_df[["Temperature", "Humidity", "Wind_Speed"]].corr(), annot=True, cmap="coolwarm", vmin=-1, vmax=1)
plt.title("Weather Feature Correlation")
plt.tight_layout()
plt.show()
