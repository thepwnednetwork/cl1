import warnings
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore")

DATA_PATH = Path("./datasets/Bengaluru_House_Data.csv")

if DATA_PATH.exists():
    df1 = pd.read_csv(DATA_PATH)
    print("Loaded original dataset:", DATA_PATH)
else:
    rng = np.random.default_rng(10)
    n = 800

    bhk = rng.choice([1, 2, 3, 4, 5], n, p=[0.1, 0.35, 0.3, 0.2, 0.05])
    sqft = np.maximum(
        350,
        bhk * rng.normal(550, 100, n) + rng.normal(0, 100, n)
    )
    price = np.maximum(15, sqft * rng.uniform(0.0035, 0.009, n))

    df1 = pd.DataFrame({
        "area_type": rng.choice(
            ["Super built-up Area", "Plot Area", "Built-up Area", "Carpet Area"], n
        ),
        "availability": rng.choice(
            ["Ready To Move", "Immediate Possession"], n
        ),
        "location": rng.choice(
            ["Whitefield", "Sarjapur Road", "Electronic City",
             "Yelahanka", "Hebbal", "Other Road"], n
        ),
        "size": [f"{b} BHK" for b in bhk],
        "society": rng.choice(["ABC", "XYZ", "PQR", np.nan], n),
        "total_sqft": sqft.astype(int).astype(str),
        "bath": np.maximum(
            1, bhk + rng.choice([-1, 0, 1], n)
        ).astype(float),
        "balcony": rng.integers(0, 4, n).astype(float),
        "price": np.round(price, 2)
    })

    df1.loc[0, "bath"] = np.nan
    df1.loc[1, "location"] = np.nan

print("\nDataset Shape:", df1.shape)
print("\nFirst Five Records:")
print(df1.head().to_string(index=False))

print("\nColumn Names:")
print(df1.columns.tolist())

drop_columns = [
    c for c in ["area_type", "society", "balcony", "availability"]
    if c in df1.columns
]

df2 = df1.drop(columns=drop_columns).copy()

print("\nMissing Values Before Cleaning:")
print(df2.isnull().sum())

df3 = df2.dropna().copy()

print("\nShape After Removing Missing Rows:", df3.shape)


def parse_bhk(value):
    try:
        return int(str(value).split()[0])
    except (ValueError, IndexError, TypeError):
        return np.nan


df3["bhk"] = df3["size"].apply(parse_bhk)

print("\nDataset After Extracting BHK:")
print(df3.head().to_string(index=False))


def convert_sqft_to_num(value):
    text = str(value).strip().replace(",", "")

    if "-" in text:
        parts = text.split("-")
        try:
            return (
                float(parts[0].strip()) + float(parts[1].strip())
            ) / 2
        except (ValueError, IndexError):
            return np.nan

    try:
        return float(text)
    except ValueError:
        return np.nan


df4 = df3.copy()

df4["total_sqft"] = df4["total_sqft"].apply(convert_sqft_to_num)

df4 = df4.dropna(
    subset=["total_sqft", "bhk", "price"]
).copy()

df4 = df4[df4["total_sqft"] > 0].copy()

df4["price_per_sqft"] = (
    df4["price"] * 100000 / df4["total_sqft"]
)

df4["location"] = df4["location"].astype(str).str.strip()

location_counts = df4["location"].value_counts()
rare_locations = location_counts[location_counts <= 10].index

df4["location"] = df4["location"].where(
    ~df4["location"].isin(rare_locations), "other"
)

df4 = df4[
    df4["total_sqft"] / df4["bhk"] >= 300
].copy()

print("\nCleaned Dataset Shape:", df4.shape)
print("\nCleaned Dataset:")
print(df4.head().to_string(index=False))

print("\nPrice Per Square Foot Summary:")
print(df4["price_per_sqft"].describe().to_string())


def remove_iqr_outliers(frame, column):
    q1 = frame[column].quantile(0.25)
    q3 = frame[column].quantile(0.75)
    iqr = q3 - q1

    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr

    return frame[frame[column].between(lower, upper)].copy()


for column in [
    "total_sqft", "bath", "price", "bhk", "price_per_sqft"
]:
    plt.figure(figsize=(6, 3))
    plt.boxplot(df4[column].dropna())
    plt.title(f"Before IQR Filtering: {column}")
    plt.ylabel(column)
    plt.tight_layout()
    plt.show()

    df4 = remove_iqr_outliers(df4, column)

print("\nShape After IQR Filtering:", df4.shape)
print("\nDataset After Outlier Removal:")
print(df4.head().to_string(index=False))

X = df4[
    ["location", "total_sqft", "bath", "bhk", "price_per_sqft"]
].copy()

X = pd.get_dummies(
    X,
    columns=["location"],
    drop_first=True
)

y = df4["price"].copy()

if len(df4) >= 5:
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=10
    )

    print("\nTraining and Testing Data Shapes:")
    print("X_train:", X_train.shape)
    print("X_test:", X_test.shape)
    print("y_train:", y_train.shape)
    print("y_test:", y_test.shape)
else:
    print("\nNot enough rows remain after filtering to split the dataset.")

print("\nPractical 4 executed successfully.")