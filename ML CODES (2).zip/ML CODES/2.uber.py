
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.pipeline import make_pipeline

# 1. Load Dataset
df = pd.read_csv(r"C:\Users\suhan\Downloads\ML CODES\uber.csv")

print("Original Dataset:")
print(df.head())

# 2. Preprocessing
df = df.dropna()

# Select useful columns
cols = ['pickup_longitude', 'pickup_latitude',
        'dropoff_longitude', 'dropoff_latitude',
        'passenger_count', 'fare_amount']

df = df[cols]

# Remove invalid values
df = df[(df['fare_amount'] > 0) & (df['fare_amount'] < 100)]
df = df[(df['passenger_count'] > 0) &
        (df['passenger_count'] <= 6)]

# Remove invalid geographical coordinates
df = df[
    (df['pickup_longitude'].between(-180, 180)) &
    (df['dropoff_longitude'].between(-180, 180)) &
    (df['pickup_latitude'].between(-90, 90)) &
    (df['dropoff_latitude'].between(-90, 90))
]

print("\nDataset after preprocessing:")
print(df.head())

# 3. Identify Outliers using IQR
Q1 = df['fare_amount'].quantile(0.25)
Q3 = df['fare_amount'].quantile(0.75)

IQR = Q3 - Q1

lower = Q1 - 1.5 * IQR
upper = Q3 + 1.5 * IQR

outliers = df[
    (df['fare_amount'] < lower) |
    (df['fare_amount'] > upper)
]

print("\nNumber of Outliers:", len(outliers))

# Visualize outliers
sns.boxplot(x=df['fare_amount'])
plt.title("Outlier Detection using Boxplot")
plt.show()

# Remove outliers
df = df[
    (df['fare_amount'] >= lower) &
    (df['fare_amount'] <= upper)
]

# 4. Check Correlation
sns.heatmap(df.corr(), annot=True, cmap='coolwarm')
plt.title("Correlation Heatmap")
plt.show()

# 5. Separate Input and Output
X = df.drop('fare_amount', axis=1)
y = df['fare_amount']

# Split into training and testing data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# 6. Create Regression Models
models = {
    "Linear Regression": LinearRegression(),
    "Ridge Regression": make_pipeline(
        StandardScaler(), Ridge()
    ),
    "Lasso Regression": make_pipeline(
        StandardScaler(), Lasso()
    )
}

# 7. Train and Evaluate Models
for name, model in models.items():

    model.fit(X_train, y_train)

    predictions = model.predict(X_test)

    r2 = r2_score(y_test, predictions)

    rmse = np.sqrt(
        mean_squared_error(y_test, predictions)
    )

    print("\n", name)
    print("R2 Score:", r2)
    print("RMSE:", rmse)
