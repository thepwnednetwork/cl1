# ASSIGNMENT 2: LINEAR, RIDGE AND LASSO REGRESSION — UBER DATASET
# Required: pip install pandas numpy scikit-learn
# Place uber.csv inside a folder named "datasets" beside this file.

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.impute import SimpleImputer
from sklearn.metrics import r2_score, mean_squared_error

df = pd.read_csv(r"C:\Users\suhan\Downloads\uber.csv\uber.csv")

# Extract hour and day of week from pickup datetime
df["pickup_datetime"] = pd.to_datetime(
    df["pickup_datetime"], errors="coerce", utc=True
)
df["hour"] = df["pickup_datetime"].dt.hour
df["day_of_week"] = df["pickup_datetime"].dt.dayofweek

# Remove unnecessary columns
columns_to_drop = [
    col for col in ["Unnamed: 0", "key", "pickup_datetime"]
    if col in df.columns
]
df = df.drop(columns=columns_to_drop)

# Convert columns to numeric and handle missing values
df = df.apply(pd.to_numeric, errors="coerce")
imputer = SimpleImputer(strategy="mean")
df = pd.DataFrame(imputer.fit_transform(df), columns=df.columns)

# Features and target
X = df.drop(columns=["fare_amount"])
y = df["fare_amount"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Standardize features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train regression models
models = {
    "Linear Regression": LinearRegression(),
    "Ridge Regression": Ridge(alpha=1.0),
    "Lasso Regression": Lasso(alpha=0.1)
}

for name, model in models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    r2 = r2_score(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    print(f"{name} - R2 Score: {r2:.4f}, RMSE: {rmse:.2f}")
