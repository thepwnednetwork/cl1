# ASSIGNMENT 4: K-MEANS CLUSTERING USING ELBOW METHOD — IRIS DATASET
# Required: pip install pandas matplotlib scikit-learn
# Place iris.csv inside a folder named "datasets" beside this file.

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

df = pd.read_csv(r"C:\Users\suhan\Downloads\Iris.csv")

# Select features, excluding first column (ID) and last column (species)
X = df.iloc[:, 1:-1]

# Standardize features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Calculate inertia for cluster counts from 1 to 10
inertia = []
for k in range(1, 11):
    kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
    kmeans.fit(X_scaled)
    inertia.append(kmeans.inertia_)

# Plot elbow curve
plt.figure(figsize=(8, 6))
plt.plot(range(1, 11), inertia, marker="o", linestyle="--")
plt.xlabel("Number of Clusters")
plt.ylabel("Inertia (Within-Cluster Sum of Squares)")
plt.title("Elbow Method for Optimal Number of Clusters")
plt.grid(True)
plt.show()
