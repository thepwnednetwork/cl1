# ASSIGNMENT 1: PRINCIPAL COMPONENT ANALYSIS (PCA) — WINE DATASET
# Required: pip install pandas matplotlib scikit-learn
# Place wine.csv inside a folder named "datasets" beside this file.

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

df = pd.read_csv(r"C:\Users\suhan\Downloads\Wine.csv")

X = df.drop(columns=["Customer_Segment"])
y = df["Customer_Segment"]

# Original data scatter plot
plt.figure(figsize=(10, 6))
for segment in sorted(y.unique()):
    part = df[df["Customer_Segment"] == segment]
    plt.scatter(part["Alcohol"], part["Malic_Acid"],
                label=f"Customer Segment {segment}", alpha=0.7)
plt.xlabel("Alcohol")
plt.ylabel("Malic Acid")
plt.title("Scatter Plot (Original Data)")
plt.legend()
plt.show()

# Standardize features and apply PCA
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

pca_df = pd.DataFrame(
    X_pca,
    columns=["Principal Component 1", "Principal Component 2"]
)
pca_df["Customer_Segment"] = y.to_numpy()

# Visualize first two principal components
plt.figure(figsize=(10, 6))
for segment in sorted(y.unique()):
    part = pca_df[pca_df["Customer_Segment"] == segment]
    plt.scatter(part["Principal Component 1"],
                part["Principal Component 2"],
                label=f"Customer Segment {segment}", alpha=0.7)
plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.title("PCA: Wine Dataset")
plt.legend()
plt.show()
