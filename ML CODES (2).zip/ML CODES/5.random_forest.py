# ASSIGNMENT 5: RANDOM FOREST CLASSIFICATION — CAR EVALUATION DATASET
# Required: pip install pandas scikit-learn
# Place car_evaluation.csv inside a folder named "datasets" beside this file.


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix
)

data = pd.read_csv(r"C:\Users\suhan\Downloads\car_evaluation.csv")

# Encode categorical/string columns
encoders = {}

for column in data.columns:
    le = LabelEncoder()
    data[column] = le.fit_transform(data[column].astype(str))
    encoders[column] = le

# Features and target (last column)
X = data.iloc[:, :-1]
y = data.iloc[:, -1]

# Split into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=40
)

# Create and train Random Forest classifier
classifier = RandomForestClassifier(
    n_estimators=100, random_state=40
)
classifier.fit(X_train, y_train)

# Predict and evaluate
y_pred = classifier.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))

print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))

print("\nClassification Report:")
print(classification_report(y_test, y_pred))


# Predict a car with Acceptable safety
predictions = classifier.predict(X_test)

target_class = encoders[data.columns[-1]].transform(["unacc"])[0]

samples = X_test[predictions == target_class]

if len(samples) > 0:
    sample_car = samples.iloc[[10]]
    prediction = classifier.predict(sample_car)

    safety = encoders[data.columns[-1]].inverse_transform(prediction)

    print("\nSample Car Safety Prediction:")
    print("Predicted Safety:", safety[0])
else:
    print("No acceptable prediction found.")
