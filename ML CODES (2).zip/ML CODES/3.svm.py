# ASSIGNMENT 3: SUPPORT VECTOR MACHINE (SVM) CLASSIFICATION
# Uses scikit-learn's built-in Digits dataset.
# Required: pip install matplotlib scikit-learn

import matplotlib.pyplot as plt
from sklearn import datasets, svm, metrics
from sklearn.model_selection import train_test_split

digits = datasets.load_digits()
X = digits.data
y = digits.target

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Create and train SVM classifier using linear kernel
classifier = svm.SVC(kernel="linear")
classifier.fit(X_train, y_train)

# Predict test data
y_pred = classifier.predict(X_test)

# Evaluate classifier
print("Accuracy:", metrics.accuracy_score(y_test, y_pred))
print("\\nConfusion Matrix:")
print(metrics.confusion_matrix(y_test, y_pred))
print("\\nClassification Report:")
print(metrics.classification_report(y_test, y_pred))

# Display test images and predicted labels
plt.figure(figsize=(10, 8))
for i in range(3):
    plt.subplot(2, 5, i + 1)
    plt.imshow(X_test[i].reshape(8, 8), cmap="gray")
    plt.title(f"Predicted: {y_pred[i]} | Actual: {y_test[i]}")
    plt.axis("off")
plt.tight_layout()
plt.show()
